import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String [] input = scanner.nextLine().split(", ");
        Articles article = new Articles(input[0],input[1],input[2]);
        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String[] commandArgs = scanner.nextLine().split(": ");
            String command = commandArgs[0];
            String output = commandArgs[1];
            if (command.equals("Edit")){
                article.Edit(output);
            } else if (command.equals("ChangeAuthor")) {
                article.ChangeAuthor(output);
            } else if (command.equals("Rename")) {
                article.Rename(output);
            }
        }
            System.out.printf("%s - %s: %s",article.getTitle(),article.getContent(),article.getAuthor());
    }
}